import logging
import os

os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
GRAPH_DIR = os.path.join(OUTPUT_DIR, "graphs")
SAMPLE_DIR = os.path.join(OUTPUT_DIR, "samples")
MODEL_PATH = os.path.join(OUTPUT_DIR, "transgan_sr.pth")
LOG_PATH = os.path.join(OUTPUT_DIR, "training.log")
os.environ.setdefault("MPLCONFIGDIR", os.path.join(OUTPUT_DIR, ".matplotlib"))

import h5py
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
from torch.utils.data import DataLoader, Dataset, random_split


DATASET_CANDIDATES = [
    os.path.join(BASE_DIR, "train.h5"),
    os.path.join(os.path.dirname(BASE_DIR), "train.h5"),
]
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
EPOCHS = 20
BATCH_SIZE = 2
LEARNING_RATE = 2e-4
TRAIN_SPLIT = 0.8
NORMALIZATION_DIVISOR = 5000.0
RANDOM_SEED = 42
NUM_WORKERS = 0
NUM_SAMPLE_IMAGES = 5
VISUAL_BANDS = (2, 1, 0)


os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(GRAPH_DIR, exist_ok=True)
os.makedirs(SAMPLE_DIR, exist_ok=True)
os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, mode="w"),
        logging.StreamHandler(),
    ],
    force=True,
)
logger = logging.getLogger("transgan")


def resolve_dataset_path():
    for path in DATASET_CANDIDATES:
        if not os.path.exists(path):
            continue
        try:
            with h5py.File(path, "r") as file:
                if "x" in file and "y" in file:
                    logger.info("Using dataset: %s", path)
                    return path
        except OSError as error:
            logger.warning("Skipping unreadable dataset %s: %s", path, error)

    raise FileNotFoundError(
        "No valid train.h5 found. Checked: " + ", ".join(DATASET_CANDIDATES)
    )


class H5Dataset(Dataset):
    def __init__(self, path):
        self.file = h5py.File(path, "r")
        self.inputs = self.file["x"]
        self.targets = self.file["y"]

    def __len__(self):
        return len(self.inputs)

    def __getitem__(self, idx):
        lr = self.inputs[idx]
        hr = self.targets[idx]

        lr = np.clip((lr / NORMALIZATION_DIVISOR) - 1.0, -1.0, 1.0)
        hr = np.clip((hr / NORMALIZATION_DIVISOR) - 1.0, -1.0, 1.0)

        lr = np.transpose(lr, (2, 0, 1))
        hr = np.transpose(hr, (2, 0, 1))

        return (
            torch.tensor(lr, dtype=torch.float32),
            torch.tensor(hr, dtype=torch.float32),
        )

    def close(self):
        if getattr(self, "file", None) is not None:
            self.file.close()
            self.file = None

    def __del__(self):
        self.close()


class TransformerBlock(nn.Module):
    def __init__(self, dim, heads=4, mlp_ratio=4):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * mlp_ratio),
            nn.GELU(),
            nn.Linear(dim * mlp_ratio, dim),
        )

    def forward(self, x):
        x = x + self.attn(self.norm1(x), self.norm1(x), self.norm1(x))[0]
        x = x + self.mlp(self.norm2(x))
        return x


class Generator(nn.Module):
    def __init__(self, in_channels=6, embed_dim=96):
        super().__init__()
        self.embed = nn.Conv2d(in_channels, embed_dim, kernel_size=3, padding=1)
        self.downsample = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim, kernel_size=4, stride=4),
            nn.GELU(),
            nn.Conv2d(embed_dim, embed_dim, kernel_size=4, stride=4),
            nn.GELU(),
        )
        self.transformer = nn.Sequential(
            TransformerBlock(embed_dim),
            TransformerBlock(embed_dim),
            TransformerBlock(embed_dim),
        )
        self.upsample = nn.Sequential(
            nn.ConvTranspose2d(embed_dim, embed_dim, kernel_size=4, stride=4),
            nn.GELU(),
            nn.ConvTranspose2d(embed_dim, embed_dim, kernel_size=4, stride=4),
            nn.GELU(),
        )
        self.refine = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim, kernel_size=3, padding=1),
            nn.GELU(),
            nn.Conv2d(embed_dim, in_channels, kernel_size=3, padding=1),
            nn.Tanh(),
        )

    def forward(self, x):
        residual = x
        x = self.embed(x)
        x = self.downsample(x)

        batch_size, channels, height, width = x.shape
        x = x.view(batch_size, channels, height * width).permute(0, 2, 1)
        x = self.transformer(x)
        x = x.permute(0, 2, 1).view(batch_size, channels, height, width)

        x = self.upsample(x)
        x = self.refine(x)
        return torch.clamp(x + residual, -1.0, 1.0)


class Discriminator(nn.Module):
    def __init__(self, in_channels=6):
        super().__init__()
        channels = in_channels * 2
        self.model = nn.Sequential(
            nn.Conv2d(channels, 64, kernel_size=4, stride=2, padding=1),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(128, 256, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(256, 1, kernel_size=4, padding=1),
        )

    def forward(self, lr, img):
        x = torch.cat([lr, img], dim=1)
        return self.model(x)


def denormalize_image(image):
    image = np.clip(image, -1.0, 1.0)
    return (image + 1.0) / 2.0


def make_display_image(image):
    image = denormalize_image(image)
    band_count = image.shape[-1]
    band_indices = [band for band in VISUAL_BANDS if band < band_count]
    if len(band_indices) < 3:
        band_indices = list(range(min(3, band_count)))

    rgb = image[..., band_indices]
    if rgb.shape[-1] == 1:
        rgb = np.repeat(rgb, 3, axis=-1)
    elif rgb.shape[-1] == 2:
        rgb = np.concatenate([rgb, rgb[..., :1]], axis=-1)

    stretched = []
    for channel_index in range(3):
        channel = rgb[..., channel_index]
        low = np.percentile(channel, 2)
        high = np.percentile(channel, 98)
        if high > low:
            channel = np.clip((channel - low) / (high - low), 0.0, 1.0)
        else:
            channel = np.clip(channel, 0.0, 1.0)
        stretched.append(channel)

    return np.stack(stretched, axis=-1)


def compute_batch_metrics(prediction, target):
    prediction_np = prediction.detach().cpu().numpy()
    target_np = target.detach().cpu().numpy()

    psnr_values = []
    ssim_values = []

    for pred_item, target_item in zip(prediction_np, target_np):
        pred_item = np.transpose(pred_item, (1, 2, 0))
        target_item = np.transpose(target_item, (1, 2, 0))
        pred_item = denormalize_image(pred_item)
        target_item = denormalize_image(target_item)

        psnr_values.append(psnr(target_item, pred_item, data_range=1.0))
        ssim_values.append(
            ssim(target_item, pred_item, channel_axis=-1, data_range=1.0)
        )

    return float(np.mean(psnr_values)), float(np.mean(ssim_values))


def save_plot(epochs, values, title, ylabel, filename):
    plt.figure(figsize=(8, 5))
    for label, series in values.items():
        plt.plot(epochs, series, label=label, linewidth=2)
    plt.title(title)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.grid(True, alpha=0.3)
    if len(values) > 1:
        plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(GRAPH_DIR, filename), dpi=200)
    plt.close()


def save_sample_images(generator, test_loader, device, pin_memory, max_samples):
    generator.eval()
    saved = 0

    with torch.no_grad():
        for lr_batch, hr_batch in test_loader:
            lr_batch = lr_batch.to(device, non_blocking=pin_memory)
            hr_batch = hr_batch.to(device, non_blocking=pin_memory)
            prediction = generator(lr_batch)

            lr_image = np.transpose(lr_batch[0].detach().cpu().numpy(), (1, 2, 0))
            hr_image = np.transpose(hr_batch[0].detach().cpu().numpy(), (1, 2, 0))
            pred_image = np.transpose(prediction[0].detach().cpu().numpy(), (1, 2, 0))

            low_res_display = make_display_image(lr_image)
            high_res_display = make_display_image(hr_image)
            generated_display = make_display_image(pred_image)

            plt.imsave(
                os.path.join(SAMPLE_DIR, f"low_res_{saved}.png"),
                low_res_display,
            )
            plt.imsave(
                os.path.join(SAMPLE_DIR, f"generated_{saved}.png"),
                generated_display,
            )
            plt.imsave(
                os.path.join(SAMPLE_DIR, f"ground_truth_{saved}.png"),
                high_res_display,
            )

            fig, axes = plt.subplots(1, 3, figsize=(12, 4))
            panels = [
                ("Low Resolution", low_res_display),
                ("Generated High Resolution", generated_display),
                ("Ground Truth", high_res_display),
            ]
            for axis, (title, image) in zip(axes, panels):
                axis.imshow(image)
                axis.set_title(title)
                axis.axis("off")

            fig.tight_layout()
            fig.savefig(
                os.path.join(SAMPLE_DIR, f"comparison_{saved}.png"),
                bbox_inches="tight",
                dpi=200,
            )
            plt.close(fig)

            saved += 1
            if saved >= max_samples:
                break

    logger.info("Saved %d sample image sets to %s", saved, SAMPLE_DIR)


def main():
    dataset_path = resolve_dataset_path()
    torch.manual_seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    dataset = H5Dataset(dataset_path)
    sample_lr, sample_hr = dataset[0]
    input_channels = sample_lr.shape[0]

    if sample_lr.shape != sample_hr.shape:
        raise ValueError(
            f"Input/output shape mismatch: {sample_lr.shape} vs {sample_hr.shape}"
        )

    logger.info("Using device: %s", DEVICE)
    logger.info("Sample tensor shape: %s", tuple(sample_lr.shape))

    train_size = int(TRAIN_SPLIT * len(dataset))
    test_size = len(dataset) - train_size
    split_generator = torch.Generator().manual_seed(RANDOM_SEED)
    train_dataset, test_dataset = random_split(
        dataset, [train_size, test_size], generator=split_generator
    )

    pin_memory = DEVICE == "cuda"
    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS,
        pin_memory=pin_memory,
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=1,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=pin_memory,
    )

    logger.info("Dataset size: %d", len(dataset))
    logger.info("Train size: %d | Test size: %d", train_size, test_size)

    generator = Generator(in_channels=input_channels).to(DEVICE)
    discriminator = Discriminator(in_channels=input_channels).to(DEVICE)

    optimizer_g = optim.Adam(generator.parameters(), lr=LEARNING_RATE, betas=(0.5, 0.999))
    optimizer_d = optim.Adam(
        discriminator.parameters(), lr=LEARNING_RATE, betas=(0.5, 0.999)
    )
    l1_loss = nn.L1Loss()

    train_losses = []
    test_losses = []
    psnr_scores = []
    ssim_scores = []

    try:
        for epoch in range(EPOCHS):
            generator.train()
            discriminator.train()
            running_g_loss = 0.0

            for lr_batch, hr_batch in train_loader:
                lr_batch = lr_batch.to(DEVICE, non_blocking=pin_memory)
                hr_batch = hr_batch.to(DEVICE, non_blocking=pin_memory)

                fake_batch = generator(lr_batch).detach()
                real_logits = discriminator(lr_batch, hr_batch)
                fake_logits = discriminator(lr_batch, fake_batch)
                d_loss = torch.mean((real_logits - 1.0) ** 2) + torch.mean(
                    fake_logits ** 2
                )

                optimizer_d.zero_grad(set_to_none=True)
                d_loss.backward()
                optimizer_d.step()

                fake_batch = generator(lr_batch)
                adv_loss = torch.mean((discriminator(lr_batch, fake_batch) - 1.0) ** 2)
                recon_loss = l1_loss(fake_batch, hr_batch)
                g_loss = adv_loss + recon_loss

                optimizer_g.zero_grad(set_to_none=True)
                g_loss.backward()
                optimizer_g.step()

                running_g_loss += g_loss.item()

            epoch_train_loss = running_g_loss / len(train_loader)
            train_losses.append(epoch_train_loss)

            generator.eval()
            epoch_test_loss = 0.0
            epoch_psnr = []
            epoch_ssim = []

            with torch.no_grad():
                for lr_batch, hr_batch in test_loader:
                    lr_batch = lr_batch.to(DEVICE, non_blocking=pin_memory)
                    hr_batch = hr_batch.to(DEVICE, non_blocking=pin_memory)

                    prediction = generator(lr_batch)
                    loss = l1_loss(prediction, hr_batch)
                    batch_psnr, batch_ssim = compute_batch_metrics(prediction, hr_batch)

                    epoch_test_loss += loss.item()
                    epoch_psnr.append(batch_psnr)
                    epoch_ssim.append(batch_ssim)

            epoch_test_loss /= len(test_loader)
            test_losses.append(epoch_test_loss)
            psnr_scores.append(float(np.mean(epoch_psnr)))
            ssim_scores.append(float(np.mean(epoch_ssim)))

            logger.info(
                "Epoch %d/%d | Train: %.4f | Test: %.4f | PSNR: %.2f | SSIM: %.4f",
                epoch + 1,
                EPOCHS,
                epoch_train_loss,
                epoch_test_loss,
                psnr_scores[-1],
                ssim_scores[-1],
            )

        epochs_range = range(1, EPOCHS + 1)
        save_plot(
            epochs_range,
            {"Train": train_losses, "Test": test_losses},
            "Training Loss vs Epoch",
            "Loss",
            "loss.png",
        )
        save_plot(
            epochs_range,
            {"PSNR": psnr_scores},
            "PSNR vs Epoch",
            "PSNR",
            "psnr.png",
        )
        save_plot(
            epochs_range,
            {"SSIM": ssim_scores},
            "SSIM vs Epoch",
            "SSIM",
            "ssim.png",
        )
        save_sample_images(
            generator,
            test_loader,
            DEVICE,
            pin_memory,
            NUM_SAMPLE_IMAGES,
        )

        torch.save(generator.state_dict(), MODEL_PATH)
        logger.info("Graphs saved to %s", GRAPH_DIR)
        logger.info("Sample PNG outputs saved to %s", SAMPLE_DIR)
        logger.info("Model saved to %s", MODEL_PATH)
    finally:
        dataset.close()


if __name__ == "__main__":
    main()
